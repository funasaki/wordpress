chmod +x /tmp/WordPress/scripts/*
